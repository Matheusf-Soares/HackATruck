//
//  ContentView.swift
//  FifthDay
//
//  Created by Student on 23/05/23.
// 51.274788, 30.227636
// 51.508016993186075, -0.13113540605258392
// 40.71286426125367%2C -74.00906207152809

import SwiftUI
import MapKit

struct ContentView: View {
    @State private var showSheet: Bool = false
    @State private var Locals: [Local] = [
        Local(Name: "London - UK",
              coordinate: CLLocationCoordinate2D(latitude: 51.508016993186075,
                    longitude: -0.13113540605258392),
              flag: "https://static.significados.com.br/foto/bandeira-reino-unido-cke.jpg",
              description: "teste"),
        Local(Name: "Chernobyl - Ukrain",
              coordinate: CLLocationCoordinate2D(latitude: 51.274788,
                    longitude: 30.227636),
              flag: "https://s2-g1.glbimg.com/PuzD6pzT8HpnjJQ7N9-DzeyWcvo=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2022/A/I/AiLQzCQr6pQbSAhod4VQ/nft-bandeira-ucrania.jpg",
              description: "teste"),
        Local(Name: "New York - USA",
              coordinate: CLLocationCoordinate2D(latitude: 40.71286426125367,
                    longitude: -74.00906207152809),
              flag: "https://static.mundoeducacao.uol.com.br/mundoeducacao/2022/05/bandeira-estados-unidos.jpg",
              description: "teste")
    ]
    
    @State private var region =  MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275), span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10))
    @State private var index: Int = 0
    var body: some View {
        VStack {
            VStack
            {
                Text("World Map")
                    .font(.title)
                    .bold()
                Text(Locals[index].Name)
                    .font(.title3)
            }.padding(.top, 50.0)
            Map(coordinateRegion: $region, annotationItems: Locals){ local in
                //MapAnnotation(coordinate:           Locals[index].coordinate){
                MapAnnotation(coordinate: local.coordinate){
                    Circle()
                        .strokeBorder(.red, lineWidth: 4)
                        .frame(width: 40, height: 40)
                        .onTapGesture {
                            showSheet.toggle()
                        }
                        .sheet(isPresented: $showSheet){
                            print("Sheet dismissed!")
                        }content: {
                            LocalInformationSheet(local: Locals[index])
                        }
//                    MapPin(coordinate: local.coordinate)
                }
                
                //}){
                
            }
            ScrollView(.horizontal){
                HStack{
                    ForEach(Locals){local in
                        Button(local.Name){
                            region = MKCoordinateRegion(center: local.coordinate, span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10))
                            index = Locals.firstIndex(where:{
                                $0.id == local.id})!
                                
                        }.buttonStyle(.borderedProminent)
                            .cornerRadius(8.5)
                            .tint(.blue)
                            .padding(.top, 5.0)
                    }
                }.ignoresSafeArea(.all)
                    .padding(.horizontal, 8.0)
            }
            
        }.ignoresSafeArea(.all)
            .padding(.bottom, 1.0)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
