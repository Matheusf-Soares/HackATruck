//
//  FifthDayApp.swift
//  FifthDay
//
//  Created by Student on 23/05/23.
//

import SwiftUI

@main
struct FifthDayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
