//
//  LocalInformationSheet.swift
//  FifthDay
//
//  Created by Student on 23/05/23.
//

import SwiftUI
import MapKit

struct LocalInformationSheet: View {
    @State var local: Local
    var body: some View {
        VStack(spacing: 20){
            Text(local.Name)
                .bold()
                .font(.title)
            AsyncImage(url: URL(string: local.flag)!, scale: 10)
                .frame(width: 10)
                .scaledToFill()
            Text(local.description)
        }
    }
}

struct LocalInformationSheet_Previews: PreviewProvider {
    static var previews: some View {
        LocalInformationSheet(
            local: Local(Name: "Chernobyl",
                  coordinate: CLLocationCoordinate2D(latitude: 51.274788,
                        longitude: 30.227636),
                  flag: "https://s2-g1.glbimg.com/PuzD6pzT8HpnjJQ7N9-DzeyWcvo=/1200x/smart/filters:cover():strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2022/A/I/AiLQzCQr6pQbSAhod4VQ/nft-bandeira-ucrania.jpg",
                  description: "teste")
        )
    }
}
