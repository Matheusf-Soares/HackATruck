//
//  Local.swift
//  FifthDay
//
//  Created by Student on 23/05/23.
//

import Foundation
import SwiftUI
import MapKit

struct Local : Identifiable {
    let id = UUID()
    let Name: String
    let coordinate: CLLocationCoordinate2D
    let flag: String
    let description: String
//    let region: MKCoordinateRegion
//    init(Name: String, coordinate: CLLocationCoordinate2D, flag: String, description: String) {
//        self.Name = Name
//        self.coordinate = coordinate
//        self.flag = flag
//        self.description = description
//        self.region = MKCoordinateRegion(center: self.coordinate, span: MKCoordinateSpan(latitudeDelta: 40, longitudeDelta: 40))
//    }
}
