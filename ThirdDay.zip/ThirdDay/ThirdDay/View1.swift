//
//  View1.swift
//  ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct View1: View {
    var body: some View {
        VStack{
            Color(.gray)
        }
    }
}

struct View1_Previews: PreviewProvider {
    static var previews: some View {
        View1()
    }
}
