//
//  View2.swift
//  ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct View2: View {
    var body: some View {
        VStack{
            Color(.blue)
        }
    }
}

struct View2_Previews: PreviewProvider {
    static var previews: some View {
        View2()
    }
}
