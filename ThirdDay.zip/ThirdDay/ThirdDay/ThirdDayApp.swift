//
//  ThirdDayApp.swift
//  ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

@main
struct ThirdDayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
