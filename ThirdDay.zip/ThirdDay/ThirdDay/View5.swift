//
//  View5.swift
//  ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct View5: View {
    var body: some View {
        VStack{
            Color(.yellow)
        }
    }
}

struct View5_Previews: PreviewProvider {
    static var previews: some View {
        View5()
    }
}
