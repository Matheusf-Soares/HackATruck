//
//  Desafio2ThirdDayApp.swift
//  Desafio2ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

@main
struct Desafio2ThirdDayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
