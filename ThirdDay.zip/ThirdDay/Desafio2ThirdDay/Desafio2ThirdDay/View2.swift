//
//  View2.swift
//  Desafio2ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct View2: View {
    @State private var Nome: String = ""
    
    var body: some View {
        NavigationStack{
            VStack{
                TextField("Insira um nome", text: $Nome)
                NavigationLink(destination: View4(name: Nome)){
                    Text("Ir para quarta tela")
                }
            }
        }
    }
}

struct View2_Previews: PreviewProvider {
    static var previews: some View {
        View2()
    }
}
