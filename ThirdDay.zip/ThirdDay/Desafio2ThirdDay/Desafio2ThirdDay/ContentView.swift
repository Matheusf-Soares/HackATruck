//
//  ContentView.swift
//  Desafio2ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct ContentView: View {
    @State private var varBool = false
    var body: some View {
        
        NavigationStack{
            
            VStack{
                NavigationLink(destination: View1()){
                    Text("Ir para segunda tela")
                }
                NavigationLink(destination: View2()){
                    Text("Ir para terceira tela")
                }
                Button("Ir para quarta tela"){
                    varBool.toggle()
                }
                    .sheet(isPresented: $varBool) {
                    print("Sheet dismissed!")
                } content: {
                    View3()
                }
            }
            //.background(.lightGray)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
