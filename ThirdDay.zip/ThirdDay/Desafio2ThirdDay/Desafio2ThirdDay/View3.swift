//
//  View3.swift
//  Desafio2ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct View3: View {
    var body: some View {
        VStack{
            Color(.gray)
        }.padding(20)
    }
}

struct View3_Previews: PreviewProvider {
    static var previews: some View {
        View3()
    }
}
