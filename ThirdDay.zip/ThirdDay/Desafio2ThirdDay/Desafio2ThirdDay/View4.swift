//
//  View4.swift
//  Desafio2ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct View4: View {
   
    var name: String
    
    var body: some View {
        Text("Vai se fuder, \(name)!!")
    }
}

