//
//  View1.swift
//  Desafio2ThirdDay
//
//  Created by Student on 19/05/23.
//

import SwiftUI

struct View1: View {
    var body: some View {
        Text("Edilson")
        Text("")
        Text("hackatruck.com.br")
        Text("edilsonalmeida_")
    }
}

struct View1_Previews: PreviewProvider {
    static var previews: some View {
        View1()
    }
}
