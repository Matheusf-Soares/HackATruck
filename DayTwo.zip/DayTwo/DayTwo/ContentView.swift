//
//  ContentView.swift
//  DayTwo
//
//  Created by Student on 18/05/23.
//

import SwiftUI

struct ContentView: View {
    @State public var weight: Double = 0.0
    @State public var height: Double = 0.0
    @State public var imc: Double = 0.0
    @State public var imcString: String = "teste"
    @State public var color: String = "Normal"
    var body: some View {
        ZStack{
            Color(color)
            VStack(){
                Spacer()
                VStack(spacing: 20){
                    Text("Calculadora de IMC")
                        .font(.title)
                        .padding(.top, 50.0)
                    
                    TextField("Weight", value: $weight, formatter: NumberFormatter() )
                        .keyboardType(.decimalPad)
                        .textContentType(.oneTimeCode)
                        .padding()
                        .frame(width: 310, height: 40)
                        .cornerRadius(100)
                        .background(.white)
                        .multilineTextAlignment(.center)
                        .cornerRadius(50)
                    TextField("Height", value: $height, formatter: NumberFormatter() )
                        .keyboardType(.decimalPad)
                        .textContentType(.oneTimeCode)
                        .padding()
                        .frame(width: 310, height: 40)
                        .cornerRadius(100)
                        .background(.white)
                        .multilineTextAlignment(.center)
                        .cornerRadius(50)
                    Button("Calculate"){
                        imc = (weight)/(pow(height, 2))
                        switch imc{
                        case 0...18.499:
                            imcString = "Baixo peso"
                            color = "LowWeight"
                        case 18.5...24.99:
                            imcString = "Normal"
                            color = "Normal"
                        case 25...29.99:
                            imcString = "Sobrepeso"
                            color = "OverWeight"
                        default:
                            imcString = "Obesidade"
                            color = "FatFuck"
                        }
                    }.buttonStyle(.borderedProminent)
                        .cornerRadius(8.5)
                        .tint(.blue)
                }
                
                Spacer()
                VStack{
                    Spacer()
                    Text(imcString)
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                    Spacer()
                }
                
                Spacer()
                Image("ImageIMC")
                    .resizable()
                    .padding(.bottom, 40.0)
                    .scaledToFit()
                Spacer()
            }
            
        }.background()
        .ignoresSafeArea()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
